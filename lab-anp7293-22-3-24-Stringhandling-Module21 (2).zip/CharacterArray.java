package com.string_lab;

public class CharacterArray
{

	public static void main(String[] args)
	{
		char[] c1 = {'N','I','V','E','D','I','T','A'};
		String str = new String(c1);
		System.out.println(str);
	}

}
